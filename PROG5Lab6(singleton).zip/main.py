from urllib.request import urlopen
from xml.etree import ElementTree as ET

import datetime

import time


class Singleton(type):
    def __init__(cls, name, bases, methods):
        cls._instance = None
        super().__init__(name, bases, methods)

    def __call__(cls, *args, **kwargs):
        if cls._instance:
            return cls._instance
        cls._instance = super().__call__(*args, **kwargs)
        return cls._instance

    def clear(cls):
        cls._instance = None
class CurrenciesList(metaclass=Singleton):
  def __init__(self):
    self.last_call = None


  def get_currencies(self, currencies_ids_lst=None):
    if self.last_call is not None and (self.last_call + datetime.timedelta(seconds=1)) > datetime.datetime.now():
      time.sleep((self.last_call + datetime.timedelta(seconds=1) - datetime.datetime.now()).total_seconds())

    self.last_call = datetime.datetime.now()

    if currencies_ids_lst is None or currencies_ids_lst == []:
        currencies_ids_lst = [
            'R01239', 'R01235', 'R01035', 'R01815', 'R01585F', 'R01589',
            'R01625', 'R01670', 'R01700J', 'R01710A'
        ]
    cur_res_str = urlopen("http://www.cbr.ru/scripts/XML_daily.asp")

    result = {}

    cur_res_xml = ET.parse(cur_res_str)
    root = cur_res_xml.getroot()

    valutes = root.findall("Valute")

    for _v in valutes:
        valute_id = _v.get('ID')

        if str(valute_id) in currencies_ids_lst:
            valute_cur_val = _v.find('Value').text
            valute_cur_name = _v.find('Name').text

            result[valute_id] = (valute_cur_val, valute_cur_name)

    return result
      
      


cur_list = CurrenciesList()

print(cur_list.get_currencies())
print(cur_list.get_currencies())
print(cur_list.get_currencies())

CurrenciesList.clear()
