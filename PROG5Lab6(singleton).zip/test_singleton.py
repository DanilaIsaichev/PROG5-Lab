from main import CurrenciesList

if __name__ == '__main__':

    import unittest

    class TestPrecisionFunc(unittest.TestCase):
        
        def test_is_instance(self):
            CurrenciesList.clear()
            
            self.assertIsInstance(CurrenciesList(), CurrenciesList)


        def test_is(self):
            CurrenciesList.clear()

            cur_list1 = CurrenciesList()
            cur_list2 = CurrenciesList()

            self.assertIs(cur_list1, cur_list2)


        def test_not_is(self):
            CurrenciesList.clear()

            cur_list1 = CurrenciesList()

            CurrenciesList.clear()

            cur_list2 = CurrenciesList()

            self.assertIsNot(cur_list1, cur_list2)


        def test_is_singleton(self):
            CurrenciesList.clear()

            cur_list1 = CurrenciesList()
            cur_list2 = CurrenciesList()
            
            cur_list2.get_currencies(['R01625', 'R01670', 'R01700J', 'R01710A'])

            self.assertEqual(id(cur_list1), id(cur_list2))


        def test_time(self):
            from time import time

            CurrenciesList.clear()

            cur_list3 = CurrenciesList()

            print(cur_list3.get_currencies())
            start = time()

            print(cur_list3.get_currencies())
            finish = time()

            self.assertLess(1, finish - start)


    unittest.main(verbosity=1)
