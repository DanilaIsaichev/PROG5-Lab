"""
Использование декоратора
"""
from urllib.request import urlopen
from xml.etree import ElementTree as ET
import datetime
import time
import json


class BaseCurrenciesList():
    def get_currencies(self, currencies_ids_lst: list) -> dict:
        if self.last_call is not None and (self.last_call + datetime.timedelta(seconds=1)) > datetime.datetime.now():
          time.sleep((self.last_call + datetime.timedelta(seconds=1) - datetime.datetime.now()).total_seconds())

        self.last_call = datetime.datetime.now()

        if currencies_ids_lst is None:
            currencies_ids_lst = [
                'R01239', 'R01235', 'R01035', 'R01815', 'R01585F', 'R01589',
                'R01625', 'R01670', 'R01700J', 'R01710A'
            ]
        cur_res_str = urlopen("http://www.cbr.ru/scripts/XML_daily.asp")

        result = {}

        cur_res_xml = ET.parse(cur_res_str)
        root = cur_res_xml.getroot()

        valutes = root.findall("Valute")

        for _v in valutes:
            valute_id = _v.get('ID')

            if str(valute_id) in currencies_ids_lst:
                valute_cur_val = _v.find('Value').text
                valute_cur_name = _v.find('Name').text

                result[valute_id] = (valute_cur_val, valute_cur_name)

        return result


class CurrenciesList(BaseCurrenciesList):
    """
        aka ConcreteComponent
    """
    def __init__(self):
        self.last_call = None
        
    def get_currencies(self, currencies_ids_lst: list) -> dict:
        if self.last_call is not None and (self.last_call + datetime.timedelta(seconds=1)) > datetime.datetime.now():
          time.sleep((self.last_call + datetime.timedelta(seconds=1) - datetime.datetime.now()).total_seconds())

        self.last_call = datetime.datetime.now()

        if currencies_ids_lst is None or currencies_ids_lst == []:
            currencies_ids_lst = [
                'R01239', 'R01235', 'R01035', 'R01815', 'R01585F', 'R01589',
                'R01625', 'R01670', 'R01700J', 'R01710A'
            ]
        cur_res_str = urlopen("http://www.cbr.ru/scripts/XML_daily.asp")

        result = {}

        cur_res_xml = ET.parse(cur_res_str)
        root = cur_res_xml.getroot()

        valutes = root.findall("Valute")

        for _v in valutes:
            valute_id = _v.get('ID')
            if str(valute_id) in currencies_ids_lst:
                valute_cur_val = _v.find('Value').text
                valute_cur_name = _v.find('Name').text

                result[valute_id] = (valute_cur_val, valute_cur_name)
        return result


class Decorator(BaseCurrenciesList):
    """
    aka Decorator из примера паттерна
    """

    __wrapped_object: BaseCurrenciesList = None

    def __init__(self, currencies_lst: BaseCurrenciesList):
        self.__wrapped_object = currencies_lst

    @property
    def wrapped_object(self) -> str:
        return self.__wrapped_object

    def get_currencies(self, currencies_ids_lst: list) -> dict:
        return self.__wrapped_object.get_currencies(currencies_ids_lst)


class ConcreteDecoratorJSON(Decorator):
    def get_currencies(self, currencies_ids_lst: list) -> str:  # JSON
        values = self.wrapped_object.get_currencies(currencies_ids_lst)
        result = json.dumps(values, ensure_ascii=False)
        return result
        


class ConcreteDecoratorCSV(Decorator):
    def get_currencies(self, currencies_ids_lst: list) -> str:  # CSV
      values = self.wrapped_object.get_currencies(currencies_ids_lst).items()
      result = ''
      for i in values:
        result += (i[0] + ', ' + i[1][0] + ', ' + i[1][1])
      return result


def show_currencies(currencies: BaseCurrenciesList):
    print(currencies.get_currencies([]))


if __name__ == "__main__":
    curlistdict = CurrenciesList()  # base
    wrappedcurlist = Decorator(curlistdict)
    wrappedcurlist_json = ConcreteDecoratorJSON(curlistdict)
    wrappedcurlist_csv = ConcreteDecoratorCSV(curlistdict)

    print('---JSON---\n')
    show_currencies(wrappedcurlist_json)
    print('---CSV---\n')
    show_currencies(wrappedcurlist_csv)
    show_currencies(wrappedcurlist)
